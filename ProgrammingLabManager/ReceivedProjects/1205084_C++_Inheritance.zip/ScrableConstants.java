
public interface ScrableConstants {
	public static final int SERVERSOCKETNUMBER=11001;
	public static final int PLAYER1=1;
	public static final int PLAYER2=2;
	public static final int PLAYER3=3;
	public static final int PLAYER4=4;
	
	
	public static final int TOTALPLAYERNUMBER=2;

}
